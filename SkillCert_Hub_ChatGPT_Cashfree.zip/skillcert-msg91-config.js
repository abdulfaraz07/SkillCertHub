/*
 SkillCert Hub configuration
 Add the CLIENT token shown by MSG91 under:
 OTP Widget -> SkillCert -> Client Side Integration -> Select Token

 Do NOT put your MSG91 AuthKey here.
*/
window.SKILLCERT_MSG91_CLIENT_TOKEN = "PASTE_MSG91_CLIENT_TOKEN_HERE";
