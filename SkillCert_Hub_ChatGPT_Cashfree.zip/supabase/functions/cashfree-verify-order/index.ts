import { serve } from "https://deno.land/std@0.224.0/http/server.ts";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers: { ...cors, "Content-Type": "application/json" } });
  try {
    const { orderId } = await req.json();
    if (!orderId) throw new Error("orderId is required.");
    const clientId = Deno.env.get("CASHFREE_CLIENT_ID");
    const clientSecret = Deno.env.get("CASHFREE_CLIENT_SECRET");
    const mode = Deno.env.get("CASHFREE_MODE") || "sandbox";
    if (!clientId || !clientSecret) throw new Error("Cashfree credentials are not configured in Supabase secrets.");
    const apiBase = mode === "production" ? "https://api.cashfree.com/pg" : "https://sandbox.cashfree.com/pg";

    const cf = await fetch(`${apiBase}/orders/${encodeURIComponent(orderId)}`, {
      headers: { "x-client-id": clientId, "x-client-secret": clientSecret, "x-api-version": "2025-01-01", "Accept": "application/json" },
    });
    const data = await cf.json();
    if (!cf.ok) return new Response(JSON.stringify({ error: data.message || "Cashfree verification failed" }), { status: 502, headers: { ...cors, "Content-Type": "application/json" } });

    // Cashfree marks the order as PAID only after successful payment. Never trust the browser callback alone.
    return new Response(JSON.stringify({ status: data.order_status, orderId: data.order_id, amount: data.order_amount }), { headers: { ...cors, "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unexpected error" }), { status: 400, headers: { ...cors, "Content-Type": "application/json" } });
  }
});
