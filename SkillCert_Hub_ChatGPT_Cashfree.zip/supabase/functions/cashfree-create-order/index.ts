import { serve } from "https://deno.land/std@0.224.0/http/server.ts";

const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return new Response(JSON.stringify({ error: "Method not allowed" }), { status: 405, headers: { ...cors, "Content-Type": "application/json" } });

  try {
    const body = await req.json();
    const clientId = Deno.env.get("CASHFREE_CLIENT_ID");
    const clientSecret = Deno.env.get("CASHFREE_CLIENT_SECRET");
    const mode = Deno.env.get("CASHFREE_MODE") || "sandbox";
    if (!clientId || !clientSecret) throw new Error("Cashfree credentials are not configured in Supabase secrets.");

    const amount = Number(body.amount);
    if (!Number.isFinite(amount) || amount <= 0) throw new Error("Invalid amount.");
    // For SkillCert, prices are controlled by the website. Do not trust arbitrary amounts in a production app;
    // map course IDs to server-side prices before going live.
    if (amount !== 149) throw new Error("Invalid SkillCert course price.");

    const customer = body.customer || {};
    const orderId = `SKILL_${crypto.randomUUID().replaceAll("-", "").slice(0, 24)}`;
    const apiBase = mode === "production" ? "https://api.cashfree.com/pg" : "https://sandbox.cashfree.com/pg";
    const returnUrl = body.returnUrl;
    if (!returnUrl || !returnUrl.startsWith("https://")) throw new Error("A valid HTTPS return URL is required.");

    const cf = await fetch(`${apiBase}/orders`, {
      method: "POST",
      headers: {
        "x-client-id": clientId,
        "x-client-secret": clientSecret,
        "x-api-version": "2025-01-01",
        "Accept": "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        order_id: orderId,
        order_amount: amount,
        order_currency: "INR",
        customer_details: {
          customer_id: String(customer.id || orderId).slice(0, 50),
          customer_name: String(customer.name || "Student").slice(0, 100),
          customer_email: String(customer.email || "student@example.com").slice(0, 100),
          customer_phone: String(customer.phone || "9999999999").replace(/\D/g, "").slice(-10),
        },
        order_meta: { return_url: `${returnUrl}&order_id={order_id}` },
        order_note: `SkillCert Hub - ${String(body.courseName || "IT Course").slice(0, 80)}`,
      }),
    });

    const data = await cf.json();
    if (!cf.ok) return new Response(JSON.stringify({ error: data.message || "Cashfree order creation failed", details: data }), { status: 502, headers: { ...cors, "Content-Type": "application/json" } });

    // In a production build, also store orderId, studentId, courseId and amount in a Supabase orders table here.
    return new Response(JSON.stringify({ order_id: data.order_id || orderId, payment_session_id: data.payment_session_id, courseId: body.courseId }), { headers: { ...cors, "Content-Type": "application/json" } });
  } catch (e) {
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "Unexpected error" }), { status: 400, headers: { ...cors, "Content-Type": "application/json" } });
  }
});
